<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no,initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"/>
<meta http-equiv="Content-type" content="text/html; charset=utf-8"/>
<title>SRA | Inicio</title>
<link href="librerias/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="librerias/bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="librerias/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.6/angular.min.js"></script>-->
<script src="librerias/jquery-1.10.2.js" ></script>
<script src="librerias/bootstrap/js/bootstrap.js"></script>
<script src="js/index.js" type="text/javascript"></script>
<script src="js/SmoothScroll.js"></script>
<script src="js/theme-scripts.js"></script>
<link href="./images/icono.png" rel='shortcut icon' type='image/png'>
<script src="librerias/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="librerias/sweetalert.css">
<link rel="stylesheet" type="text/css" href="librerias/facebook.css">
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>